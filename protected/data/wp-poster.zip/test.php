<?php
require ('/wp_poster.php');
require ('/ixr_client.php');

$poster = wp_poster::getInstance();
$blog = new wp_blog('http://wordpress/xmlrpc.php', 'test', 'test', 0);

$post = new wp_post();
$post->setTitle('текст');
$post->setDescription('текст до _читать далее_');
$post->setPostStatus('publish');
$post->setPostType('');
var_dump($blog->uploadFile('1.jpg', '1.jpg'));

//$r = $poster->post($blog, $post);
?>