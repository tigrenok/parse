<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>wp-poster | Main</title>
<script type="text/javascript" src="./js/main.js"></script>
</head>
<body>
<a href="http://www.charnad.com/">CharnaD's wp-poster</a>

Скачать можно: <br>
<a href="http://wp-poster.charnad.com/rep/wp-poster">Версия 0.2</a>.
<br><br>
Вопросы:
<ol>
<li><a href="#q1">Что это такое?</a></li>
<li><a href="#q2">Зачем это надо?</a></li>
<li><a href="#q3">Как мне отправить пост на блог?</a></li> 
<li><a href="#q4">Что значит '32700 parse error. not well formed'</a></li>
<li><a href="#q5">Что значит 'XML-RPC services are disabled on this blog.'</a></li>
<li><a href="#q6">Как мне создать категории?</a></li>
<li><a href="#q7">Как мне узнать ID поста?</a></li>
<li><a href="#q8">Когда будет можно делать ххххх?</a></li>
<li><a href="#q9">Какие версии Wordpress совместимы?</a></li>
<li><a href="#q10">Какие условия использования?</a></li>
</ol>

Ответы:
<ol>
<li>
<a name="q1">
<strong>Что это такое?</strong><br></a>
Это PHP класс написанный мной на работе для упрощения отправки постов в блог на Wordpress. По сути, сам класс является лишь фасадом к классу IXR_Client, который производит общение по протоколу XML-RPC с блогом. Класс мной выложен в свободное использование. 
</li>

<li><a name="q2">
<strong>Зачем это надо?</strong><br>
Некоторые люди хотят организовать кросс-постинг, некоторые хотят иметь возможность сразу отправлять несколько постов. У каждого свои цели. Класс - это лишь инструмент, а уж цель придумывает пользователь. 
</a></li>

<li><a name="q3">
<strong>Как мне отправить пост на блог?</strong><br>
Пример:<br>
&lt;?php<br>
require ('/wp_poster.php');<br>
require ('/ixr_client.php');<br>
<br>
$poster = wp_poster::getInstance();<br>
$blog = new wp_blog('http://wordpress/xmlrpc.php', 'test', 'test', 0);<br>
<br>
$post = new wp_post();<br>
$post-&gt;setTitle('Заголовок поста');<br>
$post-&gt;setDescription('Текст до _читать далее_');<br>
$post-&gt;setPostStatus('publish');<br>
$poster-&gt;post($blog, $post);<br>  
</a></li>

<li><a name="q4">
<strong>Что значит '32700 parse error. not well formed'</strong><br>
Это значит, что XML запрос к серверу или ответ содержат ошибки. Для начала проверьте, что вы посылаете текст в формате UTF-8.
</a><br><br></li>

<li><a name="q5">
<strong>Что значит 'XML-RPC services are disabled on this blog.'</strong><br>
Это означает, что в блоге выключена настройка, позволяющая отправлять посты через протокол XML-RPC. Вы можете ее включить в панели администратора.
</a><br><br></li>
<li><a name="q6">
<strong>Как мне создать категории?</strong><br>
$blog-&gt;createCategories(array('категория1', 'категория2'));
</a><br><br></li>
<li><a name="q7">
<strong>Как мне узнать ID поста?</strong><br>
Сейчас так:<br>
$id = $poster-&gt;post($blog, $post);<br>
Со временем будет изменено на:<br>
$posted = $poster-&gt;post($blog, $post);<br>
$id = $posted-&gt;getId();
</a><br><br></li>
<li><a name="q8">
<strong>Когда будет можно делать ххххх?</strong><br>
Тогда, когда руки дойдут. Я за это не получаю денег и делаю в свое свободное время, котрого к сожалению не очень много. 
</a><br><br></li>
<li><a name="q9">
<strong>Какие версии Wordpress совместимы?</strong><br>
Могу отвечать только за 2.6 и 2.7. С остальными не пробовал.
</a><br><br></li>
<li><a name="q10">
<strong>Какие условия использования?</strong><br>
Условия использования Wordpress и класса IXR_Client смотрите на сайте вордпресса. Мой класс распространяется для свободного использования в рамках закона. Я не несу никакой ответственности, используйте на свой страх и риск. Все авторские права принадлежат мне.
</a><br><br></li>
</ol>
</body>
</html>

