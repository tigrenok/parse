-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 20 2012 г., 10:49
-- Версия сервера: 5.1.40
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `pars`
--

-- --------------------------------------------------------

--
-- Структура таблицы `assignments`
--

CREATE TABLE IF NOT EXISTS `assignments` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `assignments`
--

INSERT INTO `assignments` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Administrator', '1', '', 's:0:"";');

-- --------------------------------------------------------

--
-- Структура таблицы `itemchildren`
--

CREATE TABLE IF NOT EXISTS `itemchildren` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `itemchildren`
--

INSERT INTO `itemchildren` (`parent`, `child`) VALUES
('Administrator', 'AdminTask'),
('AdminTask', 'ContentCreate'),
('AdminTask', 'ContentDelete'),
('AdminTask', 'ContentIndex'),
('AdminTask', 'ContentUpdate'),
('AdminTask', 'ContentView'),
('AdminTask', 'LawCreate'),
('AdminTask', 'LawDelete'),
('AdminTask', 'LawIndex'),
('AdminTask', 'LawUpdate'),
('AdminTask', 'LawView'),
('AdminTask', 'SiteCaptcha'),
('AdminTask', 'SiteIndex'),
('AdminTask', 'SitePage'),
('AdminTask', 'SitesCreate'),
('AdminTask', 'SitesDelete'),
('AdminTask', 'SitesIndex'),
('AdminTask', 'SitesParse'),
('AdminTask', 'SitesUpdate'),
('AdminTask', 'SitesView'),
('AdminTask', 'user@ActivationActivation'),
('AdminTask', 'user@AdminAdmin'),
('AdminTask', 'user@AdminCreate'),
('AdminTask', 'user@AdminDelete'),
('AdminTask', 'user@AdminUpdate'),
('AdminTask', 'user@AdminView'),
('AdminTask', 'user@ProfileChangepassword'),
('AdminTask', 'user@ProfileEdit'),
('AdminTask', 'user@ProfileFieldAdmin'),
('AdminTask', 'user@ProfileFieldCreate'),
('AdminTask', 'user@ProfileFieldDelete'),
('AdminTask', 'user@ProfileFieldUpdate'),
('AdminTask', 'user@ProfileFieldView'),
('AdminTask', 'user@ProfileProfile'),
('AdminTask', 'user@RecoveryRecovery'),
('AdminTask', 'user@RegistrationCaptcha'),
('AdminTask', 'user@RegistrationRegistration'),
('AdminTask', 'user@UserIndex'),
('AdminTask', 'user@UserView');

-- --------------------------------------------------------

--
-- Структура таблицы `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `items`
--

INSERT INTO `items` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Administrator', 2, NULL, NULL, NULL),
('AdminTask', 1, 'Правила Админа', '', 's:0:"";'),
('ContentView', 0, NULL, NULL, 'N;'),
('ContentCreate', 0, NULL, NULL, 'N;'),
('ContentUpdate', 0, NULL, NULL, 'N;'),
('ContentDelete', 0, NULL, NULL, 'N;'),
('ContentIndex', 0, NULL, NULL, 'N;'),
('LawIndex', 0, NULL, NULL, 'N;'),
('LawView', 0, NULL, NULL, 'N;'),
('LawCreate', 0, NULL, NULL, 'N;'),
('LawUpdate', 0, NULL, NULL, 'N;'),
('LawDelete', 0, NULL, NULL, 'N;'),
('SiteCaptcha', 0, NULL, NULL, 'N;'),
('SitePage', 0, NULL, NULL, 'N;'),
('SiteIndex', 0, NULL, NULL, 'N;'),
('SitesView', 0, NULL, NULL, 'N;'),
('SitesCreate', 0, NULL, NULL, 'N;'),
('SitesUpdate', 0, NULL, NULL, 'N;'),
('SitesParse', 0, NULL, NULL, 'N;'),
('SitesDelete', 0, NULL, NULL, 'N;'),
('SitesIndex', 0, NULL, NULL, 'N;'),
('user@ActivationActivation', 0, NULL, NULL, 'N;'),
('user@AdminAdmin', 0, NULL, NULL, 'N;'),
('user@AdminView', 0, NULL, NULL, 'N;'),
('user@AdminCreate', 0, NULL, NULL, 'N;'),
('user@AdminUpdate', 0, NULL, NULL, 'N;'),
('user@AdminDelete', 0, NULL, NULL, 'N;'),
('user@ProfileProfile', 0, NULL, NULL, 'N;'),
('user@ProfileEdit', 0, NULL, NULL, 'N;'),
('user@ProfileChangepassword', 0, NULL, NULL, 'N;'),
('user@ProfileFieldView', 0, NULL, NULL, 'N;'),
('user@ProfileFieldCreate', 0, NULL, NULL, 'N;'),
('user@ProfileFieldUpdate', 0, NULL, NULL, 'N;'),
('user@ProfileFieldDelete', 0, NULL, NULL, 'N;'),
('user@ProfileFieldAdmin', 0, NULL, NULL, 'N;'),
('user@RecoveryRecovery', 0, NULL, NULL, 'N;'),
('user@RegistrationCaptcha', 0, NULL, NULL, 'N;'),
('user@RegistrationRegistration', 0, NULL, NULL, 'N;'),
('user@UserView', 0, NULL, NULL, 'N;'),
('user@UserIndex', 0, NULL, NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_content`
--

CREATE TABLE IF NOT EXISTS `tbl_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `date_public` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `parse_site` varchar(255) DEFAULT NULL,
  `date_parse` varchar(255) DEFAULT NULL,
  `autor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `tbl_content`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_law`
--

CREATE TABLE IF NOT EXISTS `tbl_law` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `list_law` varchar(255) DEFAULT NULL,
  `title_law` varchar(500) DEFAULT NULL,
  `date_law` varchar(500) DEFAULT NULL,
  `autor_law` varchar(500) DEFAULT NULL,
  `img_law` varchar(500) DEFAULT NULL,
  `content_law` varchar(500) DEFAULT NULL,
  `type` enum('one','list') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `tbl_law`
--

INSERT INTO `tbl_law` (`id`, `description`, `list_law`, `title_law`, `date_law`, `autor_law`, `img_law`, `content_law`, `type`) VALUES
(1, 'zxc', 'zxc', 'zxc', '', '', 'zxc', 'zxc', 'list');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_profiles`
--

CREATE TABLE IF NOT EXISTS `tbl_profiles` (
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tbl_profiles`
--

INSERT INTO `tbl_profiles` (`user_id`) VALUES
(1),
(2),
(8),
(9);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_profiles_fields`
--

CREATE TABLE IF NOT EXISTS `tbl_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `tbl_profiles_fields`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_sites`
--

CREATE TABLE IF NOT EXISTS `tbl_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `law_id` int(11) DEFAULT NULL,
  `coding` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `tbl_sites`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `lastvisit` int(10) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `password`, `email`, `activkey`, `createtime`, `lastvisit`, `superuser`, `status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'webmaster@example.com', '9a24eff8c15a6a141ece27eb6947da0f', 1261146094, 1327045716, 1, 1),
(2, 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'demo@example.com', '099f825543f7850cc038b90aaff39fac', 1261146096, 1315036183, 0, 1),
(8, 'tiigrenok@mail.ru', '6074c6aa3488f3c2dddff2a7ca821aab', 'tiigrenok@mail.ru', '3e43b10a34e39e35adff36da620affdd', 1315038784, 1315321487, 0, 1),
(9, 'wargt@mail.ru', '96e79218965eb72c92a549dd5a330112', 'wargt@mail.ru', '1e732d1e147d969a920192c0108c3e0a', 1315321283, 1315321419, 0, 1);
